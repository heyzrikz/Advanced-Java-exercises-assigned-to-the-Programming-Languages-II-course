import java.util.Comparator;

public class A {
    private Comparator<Double> b = new B(null);
    private <T> A f(T x, T y) {
    return new B(x==y);
    }
    }
    
