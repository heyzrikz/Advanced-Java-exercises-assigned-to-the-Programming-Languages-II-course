import java.util.Comparator;

public class B extends A implements Comparator{
    B(Object o){

    }
    B(){

    }
    B(boolean f){
        
    }
    @Override
    public int compare(Object o1, Object o2) {
        // TODO Auto-generated method stub
        return 0;
    }


}