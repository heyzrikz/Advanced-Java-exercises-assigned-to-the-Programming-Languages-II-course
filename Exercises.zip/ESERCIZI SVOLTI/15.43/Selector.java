public interface Selector<T> {
    boolean select(T x);
    }
    