public class Employee extends Person{
    
}
