public class Manager extends Employee{
    
}
