public class A {
    private B myb;
private int f(B b) {
A x = B.copia(b);
myb = B.copia(77);
double d = myb.g();
return myb.g();
}
private int x = B.x;
    
}
