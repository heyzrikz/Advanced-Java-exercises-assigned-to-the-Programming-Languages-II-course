public class B extends A{
    public static int x = 0;
    public static B copia(Object b){
        return new B();
    }

    public int g(){
        return 0;
    }
}