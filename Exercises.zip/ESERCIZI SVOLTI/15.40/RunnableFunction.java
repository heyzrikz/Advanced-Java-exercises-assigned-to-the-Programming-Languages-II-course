public interface RunnableFunction<T> {
    public T run(T x);
    }
    
