

public class Main {
    public static void main(String[] args){
        Contenitore c = new Contenitore();
        Contenitore.ClasseInterna cc = c.new ClasseInterna();
    }
    
}
