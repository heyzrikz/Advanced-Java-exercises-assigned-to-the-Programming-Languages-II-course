public enum Nutrient{
    FAT,CARBO,PROTEIN;

 /*   public boolean equals(Object o){
        if(! (o.getClass() == getClass())) return false;
        Nutrient n = (Nutrient) o;
        return n.name().equals(this.name());
    }

    public int hashCode(){
        return this.name().hashCode();
    }*/
}