public class Classe {
    public int a = 1;
    public int b = 2;
    public double c = 2;
}
