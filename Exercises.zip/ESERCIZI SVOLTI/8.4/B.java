import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class B<T> implements Iterable<Number>{
B(T o){

}

Set<Number> n = new HashSet<Number>();

public static String msg(A a){
    return "";
}

public boolean check(Set<Integer> s, Integer n){
    return true;
}

public Set<Number> process(Set<?> s1 , Set<?> s2, Integer n){
    return new HashSet<Number>();
}

public Iterator<Number> iterator(){
    return n.iterator();
      
}


    
}