public interface RunnableWithArg<T> {
 void run(T x);
}
