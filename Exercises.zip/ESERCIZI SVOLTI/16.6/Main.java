public class Main {
    public static void main(String[] args){
        for (Integer n: new CommonDividers(12, 60))
        System.out.print(n + " ");
    }
    
}
