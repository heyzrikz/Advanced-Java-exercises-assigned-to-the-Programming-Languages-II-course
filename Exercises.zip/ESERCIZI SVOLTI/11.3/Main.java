public class Main {
    public static void main(String arg[]){
        Status a = Status.BUSY, b = Status.HIDDEN;
System.out.println(a. isVisible ());
System.out.println(a.canContact(b));
    }
}
