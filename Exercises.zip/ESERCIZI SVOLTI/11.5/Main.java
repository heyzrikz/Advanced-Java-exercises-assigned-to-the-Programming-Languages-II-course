import java.util.Collection;

public class Main {
    public static void main(String arg[]){
        Collection<Coin> a = Coin.convert(34),
b = Coin.convert(1000);
System.out.println(a);
System.out.println(b);
    }
}
