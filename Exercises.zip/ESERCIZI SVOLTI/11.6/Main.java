public class Main {
    public static void main(String arg[]){
        BloodType x = BloodType.ZERO;
        BloodType y = BloodType.ZERO;
        System.out.println(x.canReceiveFrom(y));
    }
}
